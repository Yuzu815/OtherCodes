import requests
import json
import time, datetime
import re
       
word = ""
nowres = "re.txt"
chose = input('请输入你的选择：\n''1、写入到翻译结果文件中。\n2、直接显示在屏幕中。\n')
print('翻译正在进行中，请稍候……\n')

def WriteFile(filename,content):
	with open(filename,'a', encoding = "UTF-8") as fw:
		fw.write(str(content)+'\n')
		
class King(object):
    def __init__(self, word):
        self.url = 'http://fy.iciba.com/ajax.php?a=fy'
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36",
        }
        self.data = {
            'f': 'auto',
            't': 'auto',
            'w': word
        }

    def get_data(self):
        response = requests.post(url=self.url, headers=self.headers, data=self.data)
        return response.content

    def parse_data(self, data):
        dict_data = json.loads(data)
        #print(dict_data)
        global word
        try:
                a = dict_data['content']['out']
                print('该单词出错，请重新输入：')
                print(word[:-1])
                word = (input() +'\n')
                return
        except:
                soundmark = dict_data['content']['ph_en']
                wordmean = str(dict_data['content']['word_mean']).replace(', ',' ').replace("'","").replace(" ", "").replace("[", "").replace("]", "")
                if len(soundmark)==0 and '(' in str(wordmean):
                        reback = re.findall(r'[(](.+?)[)]',str(wordmean))[0]
                        word = (re.findall(r'(.+[A-Za-z])', reback)[0].replace(" ", "") + '\n')
                        return
                else:
                        if chose == '1':
                                if len(soundmark)==0 :
                                        WriteFile(nowres, word[:-1])
                                else:
                                        WriteFile(nowres, word[:-1]+"  "+ "[" + soundmark + "]" )
                                WriteFile(nowres, wordmean)
                                WriteFile("logs.txt", word[:-1])
                        if chose == '2':
                                if len(soundmark)==0 :
                                        print(word[:-1])
                                else:
                                        print(word[:-1]+"  "+ "[" + soundmark + "]" )
                                print(wordmean)


            

    def run(self):
        # 发送请求，获取响应
        response = self.get_data()
        # 数据解析
        self.parse_data(response)


if __name__ == '__main__':
    WriteFile("logs.txt", (datetime.datetime.now()).strftime("[%Y-%m-%d %H:%M:%S]")+" 准备开始翻译")
    file_p = open("pre.txt", "r", encoding='UTF-8')
    line_p = file_p.readline()
    while(line_p):
        word = line_p
        if '@' in word:
            nowres = line_p[1:-1]+".txt"
            line_p = file_p.readline()
            continue
        if '[' in word:
            line_p = file_p.readline()
            continue
        king = King(word)
        king.run()
        if word != line_p:
                kings = King(word)
                kings.run()
        line_p = file_p.readline()
    WriteFile("logs.txt", '---------------------\n')

print()
