import os

def WriteFile(filename,content):
	with open(filename,'a', encoding = "UTF-8") as fw:
		fw.write(str(content)+'\n')

os.system(r"cd /d %cd% && del *.txt && cls")

#print('请输入需要翻译的单词\n按Enter结束输入:')

word = input('请输入需要翻译的单词\n按Enter结束输入:\n')

while(word !=""):
        WriteFile('pre.txt' , word)
        word = input()
